#!/system/bin/sh
MODDIR=${0%/*}

BUILD_TYPE=release

if [ "$BUILD_TYPE" == "debug" ]; then
#  touch "$MODDIR/disable"
elif [ "$BUILD_TYPE" == "release" ]; then
#  touch "$MODDIR/disable"
fi
